<?php
$hn = "localhost";
$un = "root";
$pw = "";
$db = "vocab";
$conn = mysqli_connect($hn, $un, $pw, $db);
// mysqli_set_charset($conn,"utf8");