<?php
    include_once "../includes/config.php";

    $word = $_GET['word'];
    $elaboration = $_GET['elaboration'];
    if($_GET['id'] == "")
    {
        $sql = "INSERT INTO data (`word`, `elaboration`) VALUES('$word', '$elaboration')";
    }
    else {
        $id = $_GET['id'];
        $sql = "UPDATE data SET word='$word', elaboration='$elaboration' WHERE id='$id'";
    }

    mysqli_query($conn, $sql);
    header("Location: ../index.php");
?>