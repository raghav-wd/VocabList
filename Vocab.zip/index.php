<?php
include_once "includes/config.php";

$sql = "SELECT * FROM data";
$res = mysqli_query($conn, $sql);
$row = mysqli_fetch_all($res, MYSQLI_NUM);
$num_rows = mysqli_num_rows($res);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link rel="stylesheet" href="css/vocab.css">
    <link rel="manifest" href="manifest.json" >
    
    <title>Vocab</title>
</head>
<body>
    
    <ul id="slide-out" class="sidenav">
        <li>
            <div class="user-view">
                <a href="#name"><span class="white-text name">John Doe</span></a>
                <a href="#email"><span class="white-text email">jdandturk@gmail.com</span></a>
            </div>
        </li>
        <li><a href="#!"><i class="material-icons">cloud</i>First Link With Icon</a></li>
        <li><a href="#!">Second Link</a></li>
        <li>
            <div class="divider"></div>
        </li>
        <li><a class="subheader">Subheader</a></li>
        <li><a class="waves-effect" href="#!">Third Link With Waves</a></li>
    </ul>

    <!-- <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a> -->

    <nav class="white">
        <div class="nav-wrapper">
            <form>
                <div class="input-field">
                    <input id="search" type="search" required>
                    <label class="label-icon" for="search"><i class="material-icons grey-text">search</i></label>
                    <i class="material-icons">close</i>
                </div>
            </form>
        </div>
    </nav>

    <div class="items-list">

    </div>

    <div class="overlay-writer">
        <label class="keyboard_arrow_down"><i class=" material-icons grey-text right">keyboard_arrow_down</i></label>
        <form action = "action scripts/edit.php">
        <div class="row">
            <div class="input-field col s12">
                <input value="." id="Word" type="text" class="validate" name="word">
                <label class="active" for="Word">Word</label>
            </div>
            <div class="row">
                <div class="input-field col s12">
                    <textarea id="Elaboration" class="materialize-textarea" name="elaboration">.</textarea>
                    <label for="Elaboration">Elaboration</label>
                </div>
            </div>
            <label class="delete"><i class=" material-icons grey-text right">delete</i></label>
            <input id="Id" type="text" value="" name="id" class="hide">
            <input type="submit" value="✓" class="done right">
        </form>
    </div>

    <div class="fixed-action-btn">
    <a class="btn-floating btn-large red">
        <i class="large material-icons">mode_edit</i>
    </a>
    <ul>
        <!-- <li><a class="btn-floating red"><i class="material-icons">insert_chart</i></a></li>
        <li><a class="btn-floating yellow darken-1"><i class="material-icons">format_quote</i></a></li>
        <li><a class="btn-floating green"><i class="material-icons">publish</i></a></li>
        <li><a class="btn-floating blue"><i class="material-icons">attach_file</i></a></li> -->
    </ul>
    </div>

    <script src="js/vocab.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>

        $(document).ready(function(){
        $('.sidenav').sidenav();
        $('.fixed-action-btn').floatingActionButton();
        });

        var ids = [];
        var words = [];
        var elaboration = [];
        <?php
        for($i = 0; $i < $num_rows; $i++)
        {
            echo "ids.push('".$row[$i][0]."');";
            echo "words.push('".$row[$i][1]."');";
            echo "elaboration.push('".$row[$i][2]."');";
            // array_push($words, $row[$i][1]);
        }
        
        ?>

        for(var i = 0; i<words.length; i++)
        document.querySelector('.items-list').innerHTML += 
        `<div class="item">
            <h6 class="word" data-id="${ids[i]}">${words[i]}</h6>
            <span class="elaboration grey-text">
                ${elaboration[i]}
            </span>
        </div>`;

        window.addEventListener('load', e => { //Not to block the initial load of the page with news content wanna load basic html as soon as possible
            updateNews();
            // updateSources();

            if ('serviceWorker' in navigator) {
                try {
                    navigator.serviceWorker.register('sw.js');
                    console.log('sw reg');
                }
                catch (error) {
                    console.log('sw not reg');
                }
            }
        });
        
         _('.keyboard_arrow_down').addEventListener("click", function () {
            _('.overlay-writer').style.transform = "translateX(-100vw)";
            _('.overlay-writer').style.height = "0";
            _('.overlay-writer').style.boxShadow = "0px 0px 0px 0px grey";
        });

        _('.btn-floating').addEventListener("click", function () {
            _('.overlay-writer').style.transform = "translateX(100vw)";
            _('.overlay-writer').style.height = "80vh";
            _('.overlay-writer').style.boxShadow = "1px 2px 30px 4px grey";
        });

        //Deletes an item
        _('.delete').addEventListener("click", function () {
            window.location.href = `action scripts/delete.php?id=${_('#Id').value}`;
        });

        for (var i = 0; i < countElement("item"); i++)
            _all('.item')[i].addEventListener("click", function (event) {
                // _('.overlay-writer').style.display = "inline-block";
                _('.overlay-writer').style.transform = "translateX(100vw)";
                _('.overlay-writer').style.height = "80vh";
                _('.overlay-writer').style.boxShadow = "1px 2px 30px 4px grey";
                // alert(this.innerHTML);
                _('#Id').value = this.getElementsByClassName('word')[0].getAttribute("data-id");
                _('#Word').value = this.getElementsByClassName('word')[0].innerHTML.trim();
                _('#Elaboration').value = this.getElementsByClassName('elaboration')[0].innerHTML.trim();
            // alert(this.getElementsByClassName('word')[0].innerHTML);
            });

       

        //finds the frequency of a class
        function countElement(search) {
            var itemsList = _('.items-list').innerHTML;
            var freq = 0;
            for (var i = 0; i < itemsList.length; i++)
            {
                if (itemsList.charAt(i) == search.charAt(0))
                {
                    var c = 0;
                    for (var j = 0; j < search.length; j++)
                    {
                        if (itemsList.charAt(i+j) == search.charAt(j))
                        c++;
                    }
                    if (c == search.length) freq++;
                }
            }
            return freq;
        }

        function countElement(search) {
            var itemsList = _('.items-list').innerHTML;
            var freq = 0;
            for (var i = 0; i < itemsList.length; i++) {
                if (itemsList.charAt(i) == search.charAt(0)) {
                    var c = 0;
                    for (var j = 0; j < search.length; j++) {
                        if (itemsList.charAt(i + j) == search.charAt(j))
                            c++;
                    }
                    if (c == search.length) freq++;
                }
            }
            return freq;
        }

        function _(ele) {
            return document.querySelector(ele);
        }

        function _all(ele) {
            return document.querySelectorAll(ele);
        }
    </script>

</body>
</html>